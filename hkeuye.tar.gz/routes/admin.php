<?php


Route::prefix('/dashboard')->namespace('Dashboard')->name('dashboard.')->group(function () {

    Route::get('/login', 'AuthController@showLoginForm')->name('login');
    Route::get('/logout', 'AuthController@logout')->name('logout');
    Route::post('/login', 'AuthController@login')->name('login');

    Route::middleware('admin')->group(function () {
        Route::get('/', 'DashboardController@index')->name('home');
        Route::resource('/admin', 'AdminController')->except('show');


        Route::resource('/user', 'UserController')->except(['edit', 'create', 'store', 'update']);
        Route::post('/user/status', 'UserController@updateStatus')->name('user.status');

        Route::resource('/agent', 'AgentController')->only(['show', 'index', 'destroy']);
        Route::post('/agent/status', 'AgentController@updateStatus')->name('agent.status');

        Route::resource('/order', 'OrderController')->only(['show', 'index', 'destroy']);

        Route::resource('/city', 'CityController')->except(['destroy']);

        Route::resource('/category', 'CategoryController')->except(['destroy']);

        Route::resource('/offer', 'OfferController')->only(['show', 'index', 'edit', 'update']);

        Route::resource('/page', 'PageController')->only(['show', 'index', 'edit', 'update']);
    });
});
