<?php

namespace App\Http\Controllers\Dashboard;

use App\Category;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::all();
        return view('admin.category.index')->with('categories', $categories);
    }

    public function create()
    {
        return view('admin.category.form');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'name_en' => 'required',
        ]);

        $inputs = $request->all(['name', 'name_en']);
        $category = Category::create($inputs);

        return redirect()->route('dashboard.category.index')->with('success', 'تم إضافة خدمة جديدة');
    }

    public function edit(Category $category)
    {
        return view('admin.category.form')->with('category', $category);
    }

    public function update(Request $request, Category $category)
    {
        $this->validate($request, [
            'name' => 'required',
            'name_en' => 'required',
        ]);

        $inputs = $request->all(['name', 'name_en']);
        $category = Category::updateOrCreate(['id' => $category->id], $inputs);

        return redirect()->route('dashboard.category.index')->with('success', 'تم تعديل الخدمة بنجاح');
    }
}
