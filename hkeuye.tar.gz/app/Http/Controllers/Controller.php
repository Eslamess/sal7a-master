<?php

namespace App\Http\Controllers;

use App\Agent;
use App\Libraries\ApiResponse;
use App\Libraries\JwtLibrary;
use App\User;
use Firebase\JWT\JWT;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    protected $user_id, $user_type, $user;

    function __construct()
    {
        $token = JwtLibrary::getToken();
        if ($token) {
            $data = '';
            try{
                $data = JwtLibrary::decode($token);
            }catch(\Exception $exception){
                return ApiResponse::errors(['Token' => 'Token is invalid']);
            }

            $user_id = $data->user_id;
            $user_type = $data->user_type;

            if ($user_type == 'user')
                $user = User::find($user_id);
            elseif($user_type == 'agent')
                $user = Agent::find($user_id);

            if ($user) {
                $this->user = $user;
                $this->user_id = $user_id;
                $this->user_type = $user_type;
            }
        }
    }
}
