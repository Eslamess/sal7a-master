<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3><i class="fa fa-hospital-o"></i> <span>العمال</span></h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <?php echo $__env->make('admin.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <table class="table table-hover table-striped datatable">
                            <tbody>
                            <tr>
                                <th>#</th>
                                <td><?php echo e($agent->id); ?></td>
                            </tr>
                            <tr>
                                <th>الإسم</th>
                                <td><?php echo e($agent->name); ?></td>
                            </tr>
                            <tr>
                                <th>البريد الإلكترونى</th>
                                <td><a href="mailto:<?php echo e($agent->email); ?>"><?php echo e($agent->email); ?></a></td>
                            </tr>
                            <tr>
                                <th>الهاتف</th>
                                <td><a href="tel:<?php echo e($agent->phone); ?>"><?php echo e($agent->phone); ?></a></td>
                            </tr>
                            <tr>
                                <th>المدينة</th>
                                <td><?php echo e($agent->area->name); ?></td>
                            </tr>
                            <tr>
                                <th>خط طول</th>
                                <td><?php echo e($agent->longitude); ?></td>
                            </tr>
                            <tr>
                                <th>خط عرض</th>
                                <td><?php echo e($agent->latitude); ?></td>
                            </tr>
                            <tr>
                                <th>حالة العضوية</th>
                                <td>
                                    <?php echo e($agent->getStatus()); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>التحكم</th>

                                <td>
                                    <?php if($agent->status == 'new' || $agent->status == 'banned'): ?>
                                        <form action="<?php echo e(route('dashboard.agent.status')); ?>" method="post" style="display: inline">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="status" value="active">
                                            <input type="hidden" name="agent_id" value="<?php echo e($agent->id); ?>">
                                            <button type="submit" class="btn btn-xs btn-success">تفعيل العضوية</button>
                                        </form>
                                    <?php else: ?>
                                        <form action="<?php echo e(route('dashboard.agent.status')); ?>" method="post" style="display: inline">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="status" value="banned">
                                            <input type="hidden" name="agent_id" value="<?php echo e($agent->id); ?>">
                                            <button type="submit" class="btn btn-xs btn-danger">إيقاف العضوية</button>
                                        </form>
                                    <?php endif; ?>

                                    <form action="<?php echo e(route("dashboard.agent.destroy", $agent)); ?>" method="post"
                                          style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="button" class="btn btn-danger btn-xs btn-delete">حذف
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sal7a/sal7a/resources/views/admin/agent/show.blade.php ENDPATH**/ ?>