<!DOCTYPE html>
<html lang="fa" dir="ltr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="fontiran.com:license" content="Y68A9">
    <link rel="icon" href="<?php echo e(url('assets/dashboard')); ?>/build/images/favicon.ico" type="image/ico"/>
    <title> <?php echo e(config('app.name')); ?> </title>
<!-- Bootstrap -->
    <link href="<?php echo e(url('assets/dashboard')); ?>/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(url('assets/dashboard')); ?>/vendors/bootstrap-rtl/dist/css/bootstrap-rtl.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo e(url('assets/dashboard')); ?>/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo e(url('assets/dashboard')); ?>/vendors/nprogress/nprogress.css" rel="stylesheet">

    <link href="<?php echo e(url('assets/dashboard')); ?>/build/css/owl.carousel.min.css" rel="stylesheet">
    <link href="<?php echo e(url('assets/dashboard')); ?>/build/css/owl.theme.default.min.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="<?php echo e(url('assets/dashboard')); ?>/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css"
          rel="stylesheet">
    <!-- iCheck -->
    <link href="<?php echo e(url('assets/dashboard')); ?>/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="<?php echo e(url('assets/dashboard')); ?>/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet"/>
    <!-- Custom Theme Style -->
    <link href="<?php echo e(url('assets/dashboard')); ?>/build/css/custom.min.css" rel="stylesheet">
    <link href="<?php echo e(url('assets/dashboard')); ?>/build/css/cart.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.css"/>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
          integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">


    <link rel="manifest" type="text/css" href="<?php echo e(url('js/manifest.json')); ?>">



    <style>
        .modals {
            background: #e7e5e5;
            display: flex;
            direction: rtl;
            margin: 20px 30px;
            border-radius: 100px 100px;
            box-shadow: 4px 6px 7px #8e8a8a78;
        }

        .modals .modalImg img {
            width: 100%;
            border-radius: 0px 100px 100px 0px;
            position: relative;
            /*top: 2px*/
        }

        .modals .modalImg, .modals .modalDetails {
            width: 50%
        }

        .modals .modalDetails {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            line-height: 0px
        }
    </style>

</head>
<!-- /header content -->
<?php /**PATH /home/sal7a/sal7a/resources/views/admin/layouts/header.blade.php ENDPATH**/ ?>