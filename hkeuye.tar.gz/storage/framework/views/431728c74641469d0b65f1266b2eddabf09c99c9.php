<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3><i class="fa fa-hospital-o"></i> <span>المديرين</span></h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <?php echo $__env->make('admin.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <table class="table table-hover table-striped datatable">
                            <tbody>
                            <tr>
                                <th>#</th>
                                <td><?php echo e($user->id); ?></td>
                            </tr>
                            <tr>
                                <th>الإسم</th>
                                <td><?php echo e($user->name); ?></td>
                            </tr>
                            <tr>
                                <th>البريد الإلكترونى</th>
                                <td><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></td>
                            </tr>
                            <tr>
                                <th>الهاتف</th>
                                <td><a href="tel:<?php echo e($user->phone); ?>"><?php echo e($user->phone); ?></a></td>
                            </tr>
                            <tr>
                                <th>العنوان</th>
                                <td><?php echo e($user->address); ?></td>
                            </tr>
                            <tr>
                                <th>المدينة</th>
                                <td><?php echo e($user->area->name); ?></td>
                            </tr>
                            <tr>
                                <th>خط طول</th>
                                <td><?php echo e($user->longitude); ?></td>
                            </tr>
                            <tr>
                                <th>خط عرض</th>
                                <td><?php echo e($user->latitude); ?></td>
                            </tr>
                            <tr>
                                <th>حالة العضوية</th>
                                <td>
                                    <?php echo e($user->getStatus()); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>التحكم</th>

                                <td>
                                    <?php if($user->status == 'new' || $user->status == 'banned'): ?>
                                        <form action="<?php echo e(route('dashboard.user.status')); ?>" method="post" style="display: inline">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="status" value="active">
                                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                                            <button type="submit" class="btn btn-xs btn-success">تفعيل العضوية</button>
                                        </form>
                                    <?php else: ?>
                                        <form action="<?php echo e(route('dashboard.user.status')); ?>" method="post" style="display: inline">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="status" value="banned">
                                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                                            <button type="submit" class="btn btn-xs btn-danger">إيقاف العضوية</button>
                                        </form>
                                    <?php endif; ?>

                                    <form action="<?php echo e(route("dashboard.user.destroy", $user)); ?>" method="post"
                                          style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="button" class="btn btn-danger btn-xs btn-delete">حذف
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sal7a/sal7a/resources/views/admin/user/show.blade.php ENDPATH**/ ?>