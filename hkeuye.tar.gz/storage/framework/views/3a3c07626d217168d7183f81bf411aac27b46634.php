<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3><i class="fa fa-hospital-o"></i> <span>طلب</span></h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <?php echo $__env->make('admin.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <table class="table table-hover table-striped datatable">
                            <tbody>
                            <tr>
                                <th>#</th>
                                <td><?php echo e($order->id); ?></td>
                            </tr>
                            <tr>
                                <th>تاريخ الطلب</th>
                                <td><?php echo e($order->created_at); ?></td>
                            </tr>
                            <tr>
                                <th>القسم</th>
                                <td><?php echo e($order->category->name); ?></td>
                            </tr>
                            <tr>
                                <th>المستخدم</th>
                                <td>
                                    <a href="<?php echo e(route('dashboard.user.show', $order->user)); ?>"><?php echo e($order->user->name); ?></a>
                                </td>
                            </tr>
                            <tr>
                                <th>العامل</th>
                                <td>
                                    <a href="<?php echo e(route('dashboard.agent.show', $order->agent)); ?>"><?php echo e($order->agent->name); ?></a>
                                </td>
                            </tr>
                            <tr>
                                <th>المدينة</th>
                                <td><?php echo e($order->city->name); ?></td>
                            </tr>
                            <tr>
                                <th>العنوان</th>
                                <td>
                                    <?php echo e($order->address); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>المكان</th>
                                <td>
                                    <a href="<?php echo e("https://www.google.com/maps/@".$order->latitude.",".$order->longitude.",15z"); ?>"
                                       target="_blank">
                                        <span>عرض</span>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <th>وقت الزيارة</th>
                                <td>
                                    <?php echo e($order->date); ?> <?php echo e($order->time); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>العروض</th>
                                <td>
                                    <?php if($order->offer): ?>
                                        <?php echo e($order->offer->name); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>مصاريف الزيارة</th>
                                <td>
                                    <?php echo e($order->visit_fees); ?> <span>ريال</span>
                                </td>
                            </tr>
                            <tr>
                                <th>تكلفة التصليح</th>
                                <td>
                                    <?php echo e($order->cost); ?> <span>ريال</span>
                                </td>
                            </tr>
                            <tr>
                                <th>خصم</th>
                                <td>
                                    <?php if($order->dissount): ?>
                                        <?php echo e($order->dissount); ?> <span>ريال</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>حالة الطلب</th>
                                <td>
                                    <?php echo e($order->status); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>التحكم</th>
                                <td>
                                    <form action="<?php echo e(route("dashboard.order.destroy", $order)); ?>" method="post"
                                          style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="button" class="btn btn-danger btn-xs btn-delete">حذف
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sal7a/sal7a/resources/views/admin/order/show.blade.php ENDPATH**/ ?>