<?php
echo 'Your reset code'. $token;
 ?><?php /**PATH /home/sal7a/sal7a/resources/views/mails/reset.blade.php ENDPATH**/ ?>