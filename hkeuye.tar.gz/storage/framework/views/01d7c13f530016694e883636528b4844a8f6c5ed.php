<?php $__env->startSection('content'); ?>
    <section id="parent-card" class="container">
        <h3>بحث</h3>
        <div class="x_panel">
            <div class="x_content">
                x
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sal7a/sal7a/resources/views/admin/index.blade.php ENDPATH**/ ?>