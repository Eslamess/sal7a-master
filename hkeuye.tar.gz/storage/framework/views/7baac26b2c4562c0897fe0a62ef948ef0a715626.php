<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>تعديل صفحة <?php echo e($item->name); ?></h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left"
                              action="<?php echo e(route('dashboard.page.update', $item->id)); ?>"
                              method="post" enctype="multipart/form-data" autocomplete="off">
                            <?php echo $__env->make('admin.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="form-group">
                                        <label for="content_ar">المحتوى بالعربية</label>
                                        <textarea name="content_ar" id="content_ar" rows="8"
                                                  class="form-control"><?php echo e($item->content_ar); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="form-group">
                                        <label for="content_en">المحتوى بالإنجيليزية</label>
                                        <textarea name="content_en" id="content_en" rows="8"
                                                  class="form-control" style="direction: LTR"><?php echo e($item->content_en); ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <input type="submit" class="btn btn-success" value="حفظ">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sal7a/sal7a/resources/views/admin/page/form.blade.php ENDPATH**/ ?>