<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3><i class="fa fa-hospital-o"></i> <span>الطلبات</span></h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <?php echo $__env->make('admin.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php if(count($orders) > 0): ?>
                            <table class="table table-hover table-striped datatable">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>تاريخ الطلب</th>
                                    <th>القسم</th>
                                    <th>المستخدم</th>
                                    <th>العامل</th>
                                    <th>المدينة</th>
                                    <th>حالة الطلب</th>
                                    <th>التحكم</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->created_at); ?></td>
                                        <td>
                                            <?php if($item->category): ?>
                                                <?php echo e($item->category->name); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($item->user): ?>
                                                <a href="<?php echo e(route('dashboard.user.show', $item->user)); ?>"><?php echo e($item->user->name); ?></a>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($item->agent): ?>
                                                <a href="<?php echo e(route('dashboard.agent.show', $item->agent)); ?>"><?php echo e($item->agent->name); ?></a>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($item->city): ?>
                                                <?php echo e($item->city->name); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($item->status); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('dashboard.order.show', $item)); ?>"
                                               class="btn btn-xs btn-success">عرض</a>
                                            <form action="<?php echo e(route("dashboard.order.destroy", $item)); ?>" method="post"
                                                  style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="button" class="btn btn-danger btn-xs btn-delete">حذف
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <h1 class="text-center">لا يوجد </h1>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sal7a/sal7a/resources/views/admin/order/index.blade.php ENDPATH**/ ?>