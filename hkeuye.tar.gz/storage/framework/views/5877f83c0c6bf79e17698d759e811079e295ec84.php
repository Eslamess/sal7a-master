<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            <div class="title_left">

                <h3><?php echo e(isset($admin)?'تعديل مدير '.$admin->name: 'إضافة مدير'); ?></h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <br/>
                        <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left"
                              action="<?php echo e(isset($admin)?route('dashboard.admin.update',$admin):route('dashboard.admin.store')); ?>"
                              method="post" enctype="multipart/form-data">
                            <?php echo $__env->make('admin.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo csrf_field(); ?>
                            <?php echo e(isset($admin)?method_field('PUT'):''); ?>


                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">
                                    الإسم
                                </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                    <input type="text" required="required"
                                           class="form-control col-md-7 col-xs-12" id="name" name="name"
                                           value="<?php if(old('name')): ?><?php echo e(old('name')); ?><?php elseif(isset($admin->name)): ?><?php echo e($admin->name); ?><?php endif; ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="username">
                                    إسم المستخدم
                                </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                    <input type="text" required="required"
                                           class="form-control col-md-7 col-xs-12" id="username" name="username"
                                           value="<?php if(old('username')): ?><?php echo e(old('username')); ?><?php elseif(isset($admin->username)): ?><?php echo e($admin->username); ?><?php endif; ?>">
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">
                                    البريد الالكترونى
                                </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                    <input type="text" required="required"
                                           class="form-control col-md-7 col-xs-12" id="email" name="email"
                                           value="<?php if(old('email')): ?><?php echo e(old('email')); ?><?php elseif(isset($admin->email)): ?><?php echo e($admin->email); ?><?php endif; ?>">
                                </div>
                            </div>

                            <div class="form-group" <?php echo e(!isset($admin)?'hidden':''); ?>>
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="password">
                                    تغيير كلمة المرور
                                </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                    <input type="checkbox" id="changePassword">
                                </div>
                            </div>

                            <div style="<?php echo e(isset($admin)?'display:none':''); ?>" id="changePasswordF">
                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="password">
                                        كلمة المرور
                                    </label>
                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                        <input type="password" required="required"
                                               class="form-control col-md-7 col-xs-12" id="password" name="password" <?php echo e(isset($admin)?'disabled':''); ?>>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                           for="password_confirmation">
                                        كلمة المرور تاكيد
                                    </label>
                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                        <input type="password" required="required"
                                               class="form-control col-md-7 col-xs-12" id="password_confirmation"
                                               name="password_confirmation" <?php echo e(isset($admin)?'disabled':''); ?>>
                                    </div>
                                </div>
                            </div>

                            <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                                    <button type="submit" class="btn btn-primary">حفظ</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('script'); ?>
        <script>
            $('#changePassword').on('change', function () {
                if ($(this).prop('checked'))
                    $('#changePasswordF').css('display', 'block').find('input').prop('disabled', false)
                else
                    $('#changePasswordF').css('display', 'none').find('input').prop('disabled', true)
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sal7a/sal7a/resources/views/admin/admin/form.blade.php ENDPATH**/ ?>