<div class="sidebar-footer hidden-small">
    <a data-toggle="tooltip" data-placement="top" title="تكبير" onclick="toggleFullScreen();" style="width: 33.3333%">
        <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
    </a>
    <a data-toggle="tooltip" data-placement="top" title="قفل" class="lock_btn" style="width: 33.3333%">
        <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
    </a>
    <a href="<?php echo e(route('dashboard.logout')); ?>" data-toggle="tooltip" data-placement="top" title="خروج" href="login.html" style="width: 33.3333%">
        <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
    </a>
</div>
<?php /**PATH /home/sal7a/sal7a/resources/views/admin/layouts/menu-footer-buttons.blade.php ENDPATH**/ ?>