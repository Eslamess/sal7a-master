<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            <div class="title_left">

                <h3><?php echo e(isset($category)?'تعديل الخدمة '.$category->name: 'إضافة خدمة'); ?></h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <br/>
                        <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left"
                              action="<?php echo e(isset($category)?route('dashboard.category.update',$category):route('dashboard.category.store')); ?>"
                              method="post" enctype="multipart/form-data">
                            <?php echo $__env->make('admin.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo csrf_field(); ?>
                            <?php echo e(isset($category)?method_field('PUT'):''); ?>


                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">
                                    إسم الخدمة (عربى)
                                </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                    <input type="text" required="required"
                                           class="form-control col-md-7 col-xs-12" id="name" name="name"
                                           value="<?php if(old('name')): ?><?php echo e(old('name')); ?><?php elseif(isset($category->name)): ?><?php echo e($category->name); ?><?php endif; ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name_en">
                                    إسم الخدمة (إنجليزى)
                                </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                    <input type="text" required="required"
                                           class="form-control col-md-7 col-xs-12" id="name_en" name="name_en"
                                           value="<?php if(old('name_en')): ?><?php echo e(old('name_en')); ?><?php elseif(isset($category->name_en)): ?><?php echo e($category->name_en); ?><?php endif; ?>">
                                </div>
                            </div>

                            <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                                    <button type="submit" class="btn btn-primary">حفظ</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sal7a/sal7a/resources/views/admin/category/form.blade.php ENDPATH**/ ?>