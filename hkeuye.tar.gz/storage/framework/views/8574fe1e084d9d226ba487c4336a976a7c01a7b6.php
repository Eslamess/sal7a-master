<?php
echo 'Your verify code'. $token;
 ?><?php /**PATH /home/sal7a/sal7a/resources/views/mails/email.blade.php ENDPATH**/ ?>