<?php
echo 'Your reset code'. $token;
