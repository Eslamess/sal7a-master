<?php
echo 'Your verify code'. $token;
