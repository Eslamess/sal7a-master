@extends('admin.layouts.main')
@section('content')
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3><i class="fa fa-hospital-o"></i> <span>طلب</span></h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        @include('admin.layouts.messages')
                        <table class="table table-hover table-striped datatable">
                            <tbody>
                            <tr>
                                <th>#</th>
                                <td>{{ $order->id}}</td>
                            </tr>
                            <tr>
                                <th>تاريخ الطلب</th>
                                <td>{{ $order->created_at}}</td>
                            </tr>
                            <tr>
                                <th>القسم</th>
                                <td>{{ $order->category->name}}</td>
                            </tr>
                            <tr>
                                <th>المستخدم</th>
                                <td>
                                    <a href="{{route('dashboard.user.show', $order->user)}}">{{ $order->user->name}}</a>
                                </td>
                            </tr>
                            <tr>
                                <th>العامل</th>
                                <td>
                                    <a href="{{route('dashboard.agent.show', $order->agent)}}">{{ $order->agent->name}}</a>
                                </td>
                            </tr>
                            <tr>
                                <th>المدينة</th>
                                <td>{{$order->city->name}}</td>
                            </tr>
                            <tr>
                                <th>العنوان</th>
                                <td>
                                    {{$order->address}}
                                </td>
                            </tr>
                            <tr>
                                <th>المكان</th>
                                <td>
                                    <a href="{{"https://www.google.com/maps/@".$order->latitude.",".$order->longitude.",15z"}}"
                                       target="_blank">
                                        <span>عرض</span>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <th>وقت الزيارة</th>
                                <td>
                                    {{$order->date}} {{$order->time}}
                                </td>
                            </tr>
                            <tr>
                                <th>العروض</th>
                                <td>
                                    @if($order->offer)
                                        {{$order->offer->name}}
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>مصاريف الزيارة</th>
                                <td>
                                    {{$order->visit_fees}} <span>ريال</span>
                                </td>
                            </tr>
                            <tr>
                                <th>تكلفة التصليح</th>
                                <td>
                                    {{$order->cost}} <span>ريال</span>
                                </td>
                            </tr>
                            <tr>
                                <th>خصم</th>
                                <td>
                                    @if($order->dissount)
                                        {{$order->dissount}} <span>ريال</span>
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>حالة الطلب</th>
                                <td>
                                    {{$order->status}}
                                </td>
                            </tr>
                            <tr>
                                <th>التحكم</th>
                                <td>
                                    <form action="{{route("dashboard.order.destroy", $order)}}" method="post"
                                          style="display:inline;">
                                        @csrf
                                        @method('delete')
                                        <button type="button" class="btn btn-danger btn-xs btn-delete">حذف
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
