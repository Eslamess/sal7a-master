<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <ul class="nav side-menu">

            <li><a href="{{route('dashboard.home')}}"><i class="fa fa-home"></i> الرئيسية </a></li>

            <li>
                <a><i class="fa fa-chain"></i> المديرين <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li>
                        <a href="{{route('dashboard.admin.index')}}"><i class="fa fa-eye"></i>
                            <span>عرض الكل</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{route('dashboard.admin.create')}}"><i class="fa fa-plus"></i>
                            <span>اضافه مدير </span>
                        </a>
                    </li>
                </ul>
            </li>

            <li>
                <a><i class="fa fa-chain"></i> الأعضاء <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li>
                        <a href="{{route('dashboard.user.index')}}"><i class="fa fa-eye"></i>
                            <span>عرض الكل</span>
                        </a>
                    </li>
                </ul>
            </li>

            <li>
                <a><i class="fa fa-chain"></i> العمال <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li>
                        <a href="{{route('dashboard.agent.index')}}"><i class="fa fa-eye"></i>
                            <span>عرض الكل</span>
                        </a>
                    </li>
                </ul>
            </li>

            <li>
                <a><i class="fa fa-chain"></i> الطلبات <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li>
                        <a href="{{route('dashboard.order.index')}}"><i class="fa fa-eye"></i>
                            <span>عرض الكل</span>
                        </a>
                    </li>
                </ul>
            </li>

            <li>
                <a><i class="fa fa-chain"></i> المدن <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li>
                        <a href="{{route('dashboard.city.index')}}"><i class="fa fa-eye"></i>
                            <span>عرض الكل</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{route('dashboard.city.create')}}"><i class="fa fa-plus"></i>
                            <span>إضافة مدينة</span>
                        </a>
                    </li>
                </ul>
            </li>

            <li>
                <a><i class="fa fa-chain"></i> الخدمات <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li>
                        <a href="{{route('dashboard.category.index')}}"><i class="fa fa-eye"></i>
                            <span>عرض الكل</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{route('dashboard.category.create')}}"><i class="fa fa-plus"></i>
                            <span>إضافة خدمة</span>
                        </a>
                    </li>
                </ul>
            </li>

            <li>
                <a><i class="fa fa-chain"></i> الصفحات <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li>
                        <a href="{{route('dashboard.page.index')}}"><i class="fa fa-eye"></i>
                            <span>عرض الكل</span>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</div>
