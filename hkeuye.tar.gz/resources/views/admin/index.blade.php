@extends('admin.layouts.main')
@section('content')
    <section id="parent-card" class="container">
        <h3>بحث</h3>
        <div class="x_panel">
            <div class="x_content">
                x
            </div>
        </div>
    </section>
@endsection
