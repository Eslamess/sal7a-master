@extends('admin.layouts.main')
@section('content')
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3><i class="fa fa-hospital-o"></i> <span>العمال</span></h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        @include('admin.layouts.messages')
                        <table class="table table-hover table-striped datatable">
                            <tbody>
                            <tr>
                                <th>#</th>
                                <td>{{ $agent->id}}</td>
                            </tr>
                            <tr>
                                <th>الإسم</th>
                                <td>{{ $agent->name}}</td>
                            </tr>
                            <tr>
                                <th>البريد الإلكترونى</th>
                                <td><a href="mailto:{{ $agent->email}}">{{ $agent->email}}</a></td>
                            </tr>
                            <tr>
                                <th>الهاتف</th>
                                <td><a href="tel:{{$agent->phone}}">{{$agent->phone}}</a></td>
                            </tr>
                            <tr>
                                <th>المدينة</th>
                                <td>{{$agent->area->name}}</td>
                            </tr>
                            <tr>
                                <th>خط طول</th>
                                <td>{{$agent->longitude}}</td>
                            </tr>
                            <tr>
                                <th>خط عرض</th>
                                <td>{{$agent->latitude}}</td>
                            </tr>
                            <tr>
                                <th>حالة العضوية</th>
                                <td>
                                    {{$agent->getStatus()}}
                                </td>
                            </tr>
                            <tr>
                                <th>التحكم</th>

                                <td>
                                    @if($agent->status == 'new' || $agent->status == 'banned')
                                        <form action="{{route('dashboard.agent.status')}}" method="post" style="display: inline">
                                            @csrf
                                            <input type="hidden" name="status" value="active">
                                            <input type="hidden" name="agent_id" value="{{$agent->id}}">
                                            <button type="submit" class="btn btn-xs btn-success">تفعيل العضوية</button>
                                        </form>
                                    @else
                                        <form action="{{route('dashboard.agent.status')}}" method="post" style="display: inline">
                                            @csrf
                                            <input type="hidden" name="status" value="banned">
                                            <input type="hidden" name="agent_id" value="{{$agent->id}}">
                                            <button type="submit" class="btn btn-xs btn-danger">إيقاف العضوية</button>
                                        </form>
                                    @endif

                                    <form action="{{route("dashboard.agent.destroy", $agent)}}" method="post"
                                          style="display:inline;">
                                        @csrf
                                        @method('delete')
                                        <button type="button" class="btn btn-danger btn-xs btn-delete">حذف
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
