<?php

Route::prefix('/agent')->namespace('Api\Agent')->group(function(){

    //Register as agent
    //Route::post('/register', 'AuthController@register');



});
