<?php

Route::prefix('/user')->namespace('Api\User')->group(function () {

    // Register
    Route::post('/register', 'AuthController@register');

    // Get Profile
    Route::get('/profile', 'AuthController@getProfile');
    Route::post('/profile', 'AuthController@updateProfile');
    Route::post('/password', 'AuthController@updatePassword');


});
