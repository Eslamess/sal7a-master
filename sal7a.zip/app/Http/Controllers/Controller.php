<?php

namespace App\Http\Controllers;

use App\Libraries\JwtLibrary;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    protected $user_id, $user_type;

    function __construct()
    {
        $token = JwtLibrary::getToken();
        if ($token) {
            $data = JwtLibrary::decode($token);
            $this->user_id = $data->user_id;
            $this->user_type = $data->user_type;
        }
    }
}
