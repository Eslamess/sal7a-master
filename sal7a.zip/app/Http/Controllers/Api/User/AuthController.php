<?php

namespace App\Http\Controllers\Api\User;

use App\Http\Controllers\Controller;
use App\Libraries\ApiResponse;
use App\Libraries\ApiValidator;
use App\Libraries\JwtLibrary;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $validate = ApiValidator::validate(User::registerRules());
        if ($validate) {
            return ApiResponse::errors($validate);
        }

        $inputs = $request->all('name', 'email', 'phone', 'city_id', 'address', 'longitude', 'latitude');
        $password = $request->input('password');
        $inputs['password'] = Hash::make($password);

        $user = User::create($inputs);

        return ApiResponse::data(['user' => $user]);
    }


    public function getProfile()
    {
        if ($this->user_id && $this->user_type && $this->user_type == 'user') {
            $user = User::with('area', 'area.city')->find($this->user_id);
            return ApiResponse::data(['user' => $user]);
        } else {
            return ApiResponse::errors(['account' => 'Token is invalid']);
        }
    }

    public function updateProfile(Request $request)
    {
        if ($this->user_id && $this->user_type && $this->user_type == 'user') {
            $validate = ApiValidator::validate(User::updateRules($this->user_id));
            if ($validate) {
                return ApiResponse::errors($validate);
            }

            $user = User::find($this->user_id);
            $inputs = $request->all('name', 'email', 'phone', 'city_id', 'address', 'longitude', 'latitude');
            $user->update($inputs);
            return ApiResponse::data(['user' => $user]);
        } else {
            return ApiResponse::errors(['account' => 'Token is invalid']);
        }
    }

    public function updatePassword(Request $request)
    {
        if ($this->user_id && $this->user_type && $this->user_type == 'user') {
            $validate = ApiValidator::validate([
                'password' => 'required|confirmed|min:8'
            ]);
            if ($validate) {
                return ApiResponse::errors($validate);
            }
            $user = User::find($this->user_id);
            $old_password = $request->input('old_password');
            $password = $request->input('password');

            if (Hash::check($old_password, $user->password)) {
                $user->update([
                    'password' => Hash::make($password)
                ]);
                return ApiResponse::data(['user' => $user]);
            } else {
                return ApiResponse::errors(['account' => 'Old password is incorrect']);
            }
        } else {
            return ApiResponse::errors(['account' => 'Token is invalid']);
        }
    }
}
