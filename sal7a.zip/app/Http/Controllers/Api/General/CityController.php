<?php

namespace App\Http\Controllers\Api\General;

use App\City;
use App\Http\Controllers\Controller;
use App\Libraries\ApiResponse;
use Illuminate\Http\Request;

class CityController extends Controller
{
    public function index()
    {
        $cities = City::with('areas')->where('parent_id', null)->get();
        return ApiResponse::data(['cities' => $cities]);
    }
}
