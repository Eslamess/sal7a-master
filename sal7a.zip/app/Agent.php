<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Agent extends Model
{

    protected $guarded = [];

    protected $hidden = [
        'password', 'remember_token',
    ];

    public static function registerValidate()
    {
        return [
            'name' => 'required|min:3|max:15',
            'email' => 'required|email|unique:agents',
            'phone' => 'required|unique:agents|min:10',
            'password' => 'required|confirmed|min:8',
            'city_id' => 'required|exists:cities,id',
            'category_id' => 'required|exists:categories,id',
            'birthday' => 'required|date|before:today',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
        ];
    }

    public static function loginValidate()
    {
        return [
            'username' => 'required',
            'password' => 'required'
        ];
    }

    public function city(){
        return $this->belongsTo(City::class);
    }
}
