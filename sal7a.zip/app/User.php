<?php

namespace App;

use App\Libraries\ApiResponse;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'phone', 'city_id', 'address', 'latitude', 'longitude', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public static function registerRules()
    {
        return [
            'name' => 'required|min:3|max:15',
            'email' => 'required|email|unique:users',
            'phone' => 'required|unique:users|min:10',
            'password' => 'required|confirmed|min:8',
            'city_id' => 'required|exists:cities,id',
            'address' => 'required',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
        ];
    }

    public static function updateRules($id)
    {
        return [
            'name' => 'required|min:3|max:15',
            'email' => 'required|email|unique:users,id,'.$id,
            'phone' => 'required|min:10|unique:users,id,'.$id,
            'city_id' => 'required|exists:cities,id',
            'address' => 'required',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
        ];
    }

    public static function loginValidate()
    {
        return [
            'username' => 'required',
            'password' => 'required'
        ];
    }

    public function area(){
        return $this->belongsTo(City::class, 'city_id', 'id');
    }
}
